<html>
	<body>
	<center><br><br>
	<table border=1 width=300 height=150>
		<tr><th colspan=2>Thêm thông tin một nhân viên</th></tr>
			<form action='them.php' method=post>
			<tr>
				<td>Nhập IDNV</td>
				<td><input type=text name=idnv></td>
			</tr>
			<tr>
				<td>Nhập tên</td>
				<td><input type=text name=hoten></td>
			</tr>
			<tr>
				<td>Nhập IDPB</td>
				<td><input type=text name=idpb></td>
			</tr>
			<tr>
				<td>Nhập đ.c</td>
				<td><input type=text name=diachi></td>
			</tr>
			<tr>
				<td colspan=2 align=right><input type=submit name=submit value=them></td>
			</tr>
			</form>
	</table>
	</body>
</html>