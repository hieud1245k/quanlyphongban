<html>
	<head>
		<style type="text/css">
			.title {
				display:inline;
			}
		</style>
	<head>
	<body>
		<div class='title'>
		<a href=index.php target=_parent><font size=4>CHƯƠNG TRÌNH QUẢN LÝ PHÒNG BAN</font></a>
		</div>
		<div class='title' align=right>
			<form action=xulydangnhap.php method=post target=_parent>
				Username: <input type=text name=username>
				Password: <input type=password name=password>
				<input type=submit name=submit value="Login">
			</form>
		</div>
	</body>
</html>