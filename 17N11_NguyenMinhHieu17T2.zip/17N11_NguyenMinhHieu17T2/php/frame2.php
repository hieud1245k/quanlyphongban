<html>
	<head>
		<div id=title>
		<title>Quản lý phòng ban</title>
		<meta charset="utf-8">
		<frameset border=2 rows="60,*,50">
			<frame src="trangchu1.php" />
			<frameset cols="20%,*">
				<frame name='tuychon' src='tuychon1.php' />
				<frame name='noidung' />
			</frameset>
			<frame  />
			<noframes> Trình duyệt không hỗ trợ Frame</noframes>
		</frameset>
		</div>
	</head>
</html>
