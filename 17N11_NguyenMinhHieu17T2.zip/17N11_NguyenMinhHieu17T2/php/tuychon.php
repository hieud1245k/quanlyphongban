<html>
	<head>
		<meta charset=utf-8>
	</head>
	<body>
		<p><h3>Chọn chức năng:</h3></p>
		<p><a href=xemthongtinNV.php target='noidung'>Xem thông tin NV</a><p>
		<p><a href=xemthongtinPB.php target=noidung>Xem thông tin PB</a></p>
		<p><a href=timkiem.php target=noidung>Tìm kiếm thông tin</a></p>
	</body>
</html>
	
	