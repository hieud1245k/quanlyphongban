<html>
	<body>
	<center><br><br>
	<table border=1 width=300 height=150>
		<tr><th colspan=2>Thêm thông tin một phòng ban</th></tr>
			<form action='them_pb.php' method=post>
			<tr>
				<td>Nhập IDPB</td>
				<td><input type=text name=idpb></td>
			</tr>
			<tr>
				<td>Nhập tên pb</td>
				<td><input type=text name=ten></td>
			</tr>
			<tr>
				<td>Nhập mô tả</td>
				<td><input type=text name=mota></td>
			</tr>
			<tr>
				<td colspan=2 align=right><input type=submit name=submit value=them></td>
			</tr>
			</form>
	</table>
	</body>
</html>