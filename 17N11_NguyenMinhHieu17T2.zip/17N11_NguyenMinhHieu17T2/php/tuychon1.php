<html>
	<head>
		<meta charset=utf-8>
	</head>
	<body>
		<p><h3>Chọn chức năng:</h3></p>
		<p><a href=xemthongtinNV.php target='noidung'>Xem thông tin NV</a><p>
		<p><a href=xemthongtinPB.php target=noidung>Xem thông tin PB</a></p>
		<p><a href=timkiem.php target=noidung>Tìm kiếm thông tin</a></p>
		<p><a href=themnv.php target=noidung>Thêm nhân viên</a></p>
		<p><a href=thempb.php target=noidung>Thêm phòng ban</a></p>
		<p><a href=xoanv1.php target=noidung>Xóa nhân viên</a></p>
		<p><a href=capnhat.php target=noidung>Cập nhật thông tin nhân viên</a></p>
	</body>
</html>
	
	